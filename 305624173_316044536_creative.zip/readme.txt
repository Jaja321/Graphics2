Our bonus implementaion:
Spheres that are transparent (their material has transparency>0) act as though they are made of glass.
Meaning, when rays pass through them they refract according to Snell's law. Due to the geometry of the sphere, we get a warped mirror image of the scene behind the sphere.
We attached a scene file ("glass.txt") where the effect can be clearly seen.
The default refractive index is 1.5.

To run:
java -jar bonus.jar <Input scene file> <Output image file> <Image width> <Image height> <Optional: Refractive index>

For example:
java -jar bonus.jar glass.txt glass.png 500 500 1.4